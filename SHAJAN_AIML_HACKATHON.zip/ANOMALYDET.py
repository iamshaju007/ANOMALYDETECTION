import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import plotly.express as px
import zipfile
import os
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler
import streamlit as st

# Function to extract and read CSV from ZIP
def extract_and_load_data(zip_file_path):
    extracted_dir = 'extracted_data'
    
    # Remove the extracted directory if it already exists
    if os.path.exists(extracted_dir):
        for root, dirs, files in os.walk(extracted_dir, topdown=False):
            for name in files:
                os.remove(os.path.join(root, name))
            for name in dirs:
                os.rmdir(os.path.join(root, name))
        os.rmdir(extracted_dir)
    
    # Extract the zip file
    with zipfile.ZipFile(zip_file_path, 'r') as zip_ref:
        zip_ref.extractall(extracted_dir)

    # Find the CSV files
    csv_file_names = []
    for root, dirs, files in os.walk(extracted_dir):
        for file in files:
            if file.endswith('.csv'):
                csv_file_names.append(os.path.join(root, file))

    if not csv_file_names:
        raise FileNotFoundError("No CSV files found in the extracted directory.")
    
    # Load and concatenate data from all CSV files
    data_frames = []
    for csv_file in csv_file_names:
        df = pd.read_csv(csv_file, encoding='ISO-8859-1')
        df = df.rename(columns=lambda x: x.strip())  # Remove extra spaces
        data_frames.append(df)
    
    data = pd.concat(data_frames, ignore_index=True)
    
    # Check for required columns
    print("Columns available in the data:", data.columns.tolist())
    
    if 'timestamp' in data.columns and 'value' in data.columns:
        data['timestamp'] = pd.to_datetime(data['timestamp'])
        data.set_index('timestamp', inplace=True)
        data = data[['value']]  # Keep only the 'value' column
        data = data.fillna(method='ffill')
        return data
    else:
        raise KeyError("The required columns ('timestamp' and 'value') are missing from the data.")

# Function to perform anomaly detection
def perform_anomaly_detection(data):
    features = ['value']
    scaler = StandardScaler()
    data_scaled = scaler.fit_transform(data[features])
    
    model = IsolationForest(contamination=0.01, random_state=42)
    data['anomaly'] = model.fit_predict(data_scaled)
    data['anomaly'] = data['anomaly'].map({1: 0, -1: 1})  # Map anomalies to 1 for clarity
    return data

# Function to create conclusion based on anomaly detection
def generate_conclusion(data):
    anomaly_count = data['anomaly'].sum()
    total_points = len(data)
    
    conclusion = f"In the dataset, {anomaly_count} anomalies were detected out of {total_points} data points.\n\n"
    
    if anomaly_count > 0:
        conclusion += ("Anomalies are deviations from the expected pattern, which may represent unusual behavior or outliers in the data. "
                       "These could signal underlying problems, such as sudden spikes in usage, system failures, or irregular operational behaviors.\n\n"
                       "A further investigation should be performed to assess the root cause of these anomalies, which could involve looking at the time "
                       "range of the anomalies to correlate with specific events or incidents.")
    else:
        conclusion += "No significant anomalies were detected in the dataset, indicating that the data trends are normal and consistent over time."
    
    return conclusion

# Function to create Streamlit app
def streamlit_app():
    st.title('Anomaly Detection in Time Series Data')
    
    # File uploader for ZIP file
    uploaded_file = st.file_uploader("Choose a ZIP file", type="zip")
    if uploaded_file:
        # Save the uploaded file
        zip_file_path = 'uploaded_file.zip'
        with open(zip_file_path, 'wb') as f:
            f.write(uploaded_file.read())
        
        # Extract and load data
        try:
            # 1. **Input Data**
            data = extract_and_load_data(zip_file_path)
            st.write("### Input Data Sample:")
            st.write(data.head())
            
            # 2. **Data Analysis**
            st.write("### Data Analysis:")
            st.write(f"Total data points: {len(data)}")
            st.write(f"Time Range: {data.index.min()} to {data.index.max()}")
            
            # Perform anomaly detection
            data = perform_anomaly_detection(data)
            
            # 3. **Graph - Anomaly Detection Results**
            st.write("### Anomaly Detection Results:")
            
            # Improved Matplotlib Plot
            fig, ax = plt.subplots(figsize=(12, 6))
            ax.plot(data.index, data['value'], label='Value', color='blue', alpha=0.6, lw=2)
            
            # Highlight anomalies with distinct markers
            anomalies = data[data['anomaly'] == 1]
            ax.scatter(anomalies.index, anomalies['value'], color='red', label='Anomalies', s=50, marker='x')
            
            ax.set_title('Anomaly Detection in Time Series Data', fontsize=16)
            ax.set_xlabel('Timestamp', fontsize=14)
            ax.set_ylabel('Value', fontsize=14)
            ax.legend()
            st.pyplot(fig)
            
            # Interactive Plot using Plotly
            st.write("#### Interactive Plot:")
            fig = px.scatter(data, x=data.index, y='value', color='anomaly', title='Anomaly Detection', 
                             labels={'anomaly': 'Anomaly Status'})
            fig.update_traces(marker=dict(size=8, line=dict(width=1, color='DarkSlateGrey')))
            fig.update_layout(legend_title_text='Anomaly', xaxis_title='Timestamp', yaxis_title='Value')
            st.plotly_chart(fig)
            
            # 4. **Conclusion**
            st.write("### Conclusion:")
            conclusion = generate_conclusion(data)
            st.write(conclusion)
        
        except Exception as e:
            st.error(f"An error occurred: {str(e)}")

if __name__ == "__main__":
    streamlit_app()





